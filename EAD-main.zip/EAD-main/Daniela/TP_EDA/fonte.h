﻿#include <stdio.h>
#include <stdlib.h>

/* Struct usada para criar os nós da lista dos meios de transporte */
typedef struct meios {
	int codigo; 			// código do meio de mobilidade elétrica
	char tipo[55]; 			// tipo de transporte 
	float custo;			// custo do aluguer
	struct meios* next; 	// próximo elemento da lista ligada
} Meios;


/* Struct usada para criar os nós da lista dos clientes */
typedef struct clientes
{
	char nome[50];			// nome do cliente
	char nif[50];			// nif do cliente
	char email[50];			// email do cliente
	char password[50];		// password da conta do cliente		
	float saldo;			// saldo do cliente
	struct clientes* next;	// próximo elemento da lista ligada
} Clientes;

/* Struct usada para criar os nós da lista dos gestores */
typedef struct gestores
{
	int id;			// email do gestor
	int codigo;				// código de acesso do gestor
	struct gestores* next;	// próximo elemento da lista ligada
} Gestores;

/* Struct usada para criar os nós da lista dos alugueres*/
typedef struct alugueres {
	int codigo;				// código do meio de mobilidade
	float custo;			// custo do aluguer
	char email[50];			// email do cliente que realizou o aluguer
	struct alugueres* next;	// próximo elemento da lista ligada
} Alugueres;


Clientes* guardarDadosClientes(Clientes* lista_clientes);
Clientes* receberDadosClientes();
int imprimirClientes(Clientes* lista_clientes);
int verificarCliente(char email[50], char password[50], Clientes* lista);
int verificarNIF(char nif[50], Clientes* lista_clientes);
int verificarEmail(char email[50], Clientes* lista_clientes);
Clientes* registarCliente(char nome[50], char nif[50], char email[50], char password[50], float saldo, Clientes* lista_clientes);
Clientes* alterarEmailCliente(char email[50], char novoemail[50], Clientes* lista_clientes);
Clientes* carregarSaldo(char email[50], float montante, Clientes* lista_clientes);
Clientes* removerCliente(char email[50], Clientes* lista_clientes);
void trocaClientes(Clientes* cliente1, Clientes* cliente2);
void bubbleSortClientes(Clientes* lista_clientes);

Gestores* guardarDadosGestores(Gestores* lista_gestores);
Gestores* receberDadosGestores();
Gestores* adicionarGestor(Gestores* lista_gestores, int id, int codigo);
int verificarGestor(int id, Gestores* lista_gestores);
int verificarGestorLogin(int id, int codigo, Gestores* lista_gestores);
int imprimirGestores(Gestores* lista_gestores);
Gestores* removerGestor(int id, Gestores* lista_gestores);


Meios* guardarDadosMeios(Meios* lista_meios);
Meios* receberDadosMeios();
Meios* registarMeio(int codigo, char tipo[50], float custo, Meios* lista_meios);
int imprimirMeiosDisponiveis(Meios* lista_meios, Alugueres* lista_alugueres);
int verificarCodigo(int codigo, Meios* lista_meios);
void imprimirMeios(Meios* lista_meios);
Meios* removerMeio(int codigo, Meios* lista_meios);

Alugueres* guardarDadosAlugueres(Alugueres* lista_alugueres);
int verificarSaldo(Meios* lista_meios, Clientes* lista_clientes, Alugueres* lista_alugueres, char email[50], int codigo);
Alugueres* realizarAluguer(Alugueres* lista_alugueres, int codigo, float custo, char email[50]);
Alugueres* receberDadosAlugueres();
Alugueres* alterarEmail(char email[50], char novoemail[50], Alugueres* lista_alugueres);
int imprimirAlugueres(Alugueres* lista_alugueres);

