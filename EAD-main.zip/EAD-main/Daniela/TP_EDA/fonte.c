#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonte.h"

#pragma region Dados

/**
* @brief Fun��o usada para ler um ficheiro e armazenar os dados numa lista
* @return Lista ligada com os dados dos clientes
*/
Clientes* receberDadosClientes() {
    FILE* fp;

    fp = fopen("clientes.txt", "r");

    if (fp == NULL)
    {
        printf("Erro ao receber dados! Renicie a aplica��o!\n");
        return NULL;
    }

    Clientes* lista_clientes = NULL;

    while (!feof(fp))
    {
        char nome[50];
        char nif[50];
        char email[50];
        char password[50];
        float saldo;

        fscanf(fp, "%[^;];%[^;];%[^;];%[^;];%f\n", nome, nif, email, password, &saldo);

        Clientes* cliente = (Clientes*)malloc(sizeof(Clientes));

        if (cliente == NULL)
        {
            printf("Erro ao alocar a mem�ria de um cliente!\n");
            fclose(fp);
            return lista_clientes;
        }

        strcpy(cliente->nome, nome);
        strcpy(cliente->nif, nif);
        strcpy(cliente->email, email);
        strcpy(cliente->password, password);
        cliente->saldo = saldo;

        cliente->next = lista_clientes;
        lista_clientes = cliente;
    }

    fclose(fp);
    return lista_clientes;
}

/**
 * @brief Fun��o usada para ler um ficheiro e armazenar os dados numa lista
 * @return Lista ligada com os dados dos gestores
 */
Gestores* receberDadosGestores() {

    FILE* fp;

    fp = fopen("gestores.txt", "r");

    if (fp == NULL)
    {
        printf("Erro ao receber dados! Renicie a aplica��o!\n");
        return NULL;
    }

    Gestores* lista_gestores = NULL;

    while (!feof(fp))
    {
        int id, codigo;
        fscanf(fp, "%d;%d", &id, &codigo);

        Gestores* gestor = (Gestores*)malloc(sizeof(Gestores));

        if (gestor == NULL)
        {
            printf("Erro ao alocar a mem�ria de um cliente!\n");
            fclose(fp);
            return lista_gestores;
        }

        gestor->id = id;
        gestor->codigo = codigo;
        gestor->next = lista_gestores;
        lista_gestores = gestor;
    }

    fclose(fp);
    return lista_gestores;
}

/**
 * @brief Fun��o usada para ler um ficheiro e armazenar os dados numa lista
 * @return Lista ligada com os dados dos meios
 */
Meios* receberDadosMeios() {
    FILE* fp;

    fp = fopen("meios.txt", "r");

    if (fp == NULL) {
        printf("Erro ao receber dados! Renicie a aplica��o!\n");
        return NULL;
    }

    Meios* lista_meios = NULL;

    while (!feof(fp))
    {
        int codigo;
        char tipo[55];
        float custo;
        
        fscanf(fp, "%d;%[^;];%f", &codigo, tipo, &custo);

        Meios* meio = (Meios*)malloc(sizeof(Meios));

        if (meio == NULL)
        {
            printf("Erro ao alocar a mem�ria de um meio!\n");
            fclose(fp);
            return lista_meios;
        }

        meio->codigo = codigo;
        strcpy(meio->tipo, tipo);
        meio->custo = custo;
        meio->next = lista_meios;
        lista_meios = meio;
    }

    fclose(fp);
    return lista_meios;
}

/**
 * @brief Fun��o usada para ler um ficheiro e armazenar os dados numa lista
 * @return Lista ligada com os dados dos Alugueres
 */
Alugueres* receberDadosAlugueres() {
    FILE* fp;

    fp = fopen("alugueres.txt", "r");

    if (fp == NULL)
    {
        printf("Erro ao receber dados! Renicie a aplica��o!\n");
        return NULL;
    }

    Alugueres* lista_alugueres = NULL;

    while (!feof(fp))
    {
        int codigo;
        float custo;
        char email[50];

        fscanf(fp, "%d;%f;%s", &codigo, &custo, email);

        Alugueres* aluguer = (Alugueres*)malloc(sizeof(Alugueres));

        if (aluguer == NULL)
        {
            printf("Erro ao alocar a mem�ria de um aluguer!\n");
            fclose(fp);
            return lista_alugueres;
        }

        aluguer->codigo = codigo;
        aluguer->custo = custo;
        strcpy(aluguer->email, email);
        aluguer->next = lista_alugueres;
        lista_alugueres = aluguer;
    }

    fclose(fp);
    return lista_alugueres;
}

/**
 * @brief Fun��o utilizada para escrever os dados da lista num ficheiro bin�rio
 * @param Lista ligada que cont�m os dados dos clientes
 */
Clientes* guardarDadosClientes(Clientes* lista_clientes) {
    Clientes* clienteAtual = lista_clientes;
    FILE* fp;
    fp = fopen("clientes.bin", "w+");
    if (fp == NULL) {
        printf("Erro ao abrir o arquivo para escrita\n");
        return NULL; // ou uma outra forma de lidar com o erro
    }
    while (clienteAtual != NULL)
    {
        Clientes cliente;
        strcpy(cliente.nome, clienteAtual->nome);
        strcpy(cliente.nif, clienteAtual->nif);
        strcpy(cliente.email, clienteAtual->email);
        strcpy(cliente.password, clienteAtual->password);
        cliente.saldo = clienteAtual->saldo;
        fprintf(fp, "%s %s %s %s %.2f\n", cliente.nome, cliente.nif, cliente.email, cliente.password, cliente.saldo);

        clienteAtual = clienteAtual->next;
    }
    fclose(fp);
}

/**
 * @brief Fun��o utilizada para escrever os dados da lista num ficheiro bin�rio
 * @param Lista ligada que cont�m os dados dos gestores
 */
Gestores* guardarDadosGestores(Gestores* lista_gestores) {
    Gestores* gestorAtual = lista_gestores;
    FILE* fp;
    fp = fopen("gestores.bin", "w+");
    if (fp == NULL) {
        printf("Erro ao abrir o arquivo para escrita\n");
        return NULL;
    }
    while (gestorAtual != NULL)
    {
        Gestores gestor;
        gestor.id = gestorAtual->id;
        gestor.codigo = gestorAtual->codigo;
        fprintf(fp, "%d %d\n", gestor.id, gestor.codigo);

        gestorAtual = gestorAtual->next;
    }
    fclose(fp);
}

/**
 * @brief Fun��o utilizada para escrever os dados da lista num ficheiro bin�rio
 * @param Lista ligada que cont�m os dados dos meios
 */
Meios* guardarDadosMeios(Meios* lista_meios) {
    Meios* meioAtual = lista_meios;
    FILE* fp;
    fp = fopen("meios.bin", "w+");
    if (fp == NULL) {
        printf("Erro ao abrir o arquivo para escrita\n");
        return NULL;
    }
    while (meioAtual != NULL)
    {
        Meios meio;
        meio.codigo = meioAtual->codigo;
        strcpy(meio.tipo, meioAtual->tipo);
        meio.custo = meioAtual->custo;

        fprintf(fp, "%d %s %.2f\n", meio.codigo, meio.tipo, meio.custo);

        meioAtual = meioAtual->next;
    }
    fclose(fp);
}

/**
 * @brief Fun��o utilizada para escrever os dados da lista num ficheiro bin�rio
 * @param Lista ligada que cont�m os dados dos alugueres
 */
Alugueres* guardarDadosAlugueres(Alugueres* lista_alugueres) {
    Alugueres* aluguerAtual = lista_alugueres;
    FILE* fp;
    fp = fopen("alugueres.bin", "w+");
    if (fp == NULL) {
        printf("Erro ao abrir o arquivo para escrita\n");
        return NULL;
    }
    while (aluguerAtual != NULL)
    {
        Alugueres aluguer;
        aluguer.codigo = aluguerAtual->codigo;
        aluguer.custo = aluguerAtual->custo;
        strcpy(aluguer.email, aluguerAtual->email);

        fprintf(fp, "%d %.2f %s\n", aluguer.codigo, aluguer.custo, aluguer.email);

        aluguerAtual = aluguerAtual->next;
    }

    fclose(fp);
}

/**
 * @brief Fun��o utilizada para imprimir todos os meios
 * @param Lista ligada que cont�m os dados dos meios
 */
void imprimirMeios(Meios* lista_meios) {
    Meios* meioAtual = lista_meios;
    while (meioAtual != NULL)
    {
        printf("| Codigo: %d | Tipo: %s | Custo: %.2f", meioAtual->codigo, meioAtual->tipo, meioAtual->custo);
        meioAtual = meioAtual->next;
    }
}

/**
 * @brief Fun��o utilizada para imprimir apenas os meios dispon�veis (n�o t�m aluguer ativo)
 * @param[1] Lista ligada que cont�m os dados dos meios
 * @param[2] Lista ligada que cont�m os dados dos alugueres
 */
int imprimirMeiosDisponiveis(Meios* lista_meios, Alugueres* lista_alugueres) {
    
    
    Meios* meioAtual = lista_meios;
    while (meioAtual != NULL)
    {
        int verificar = 0;
        Alugueres* aluguerAtual = lista_alugueres;
        while (aluguerAtual != NULL)
        {
            if (aluguerAtual->codigo == meioAtual->codigo) {
                verificar = 1;
                break;
            }
            aluguerAtual = aluguerAtual->next;
        }
        if (verificar == 0)
        {
            printf("| Codigo: %d | Tipo: %s | Custo: %f |\n", meioAtual->codigo, meioAtual->tipo, meioAtual->custo);
        }
        meioAtual = meioAtual->next;
    }
}

/**
 * @brief Fun��o utilizada para imprimir todos os clientes
 * @param Lista ligada que cont�m os dados dos clientes
 */
int imprimirClientes(Clientes* lista_clientes) {
    Clientes* clienteAtual = lista_clientes;
    while (clienteAtual != NULL) {
        printf("| Nome: %s | NIF: %s | Email: %s | Saldo: %f |\n", clienteAtual->nome, clienteAtual->nif, clienteAtual->email,
            clienteAtual->saldo);
        clienteAtual = clienteAtual->next;
    }
    return 0;
}

/**
 * @brief Fun��o utilizada para imprimir todos os alugueres
 * @param Lista ligada que cont�m os dados dos alugueres
 */
int imprimirAlugueres(Alugueres* lista_alugueres) {
    Alugueres* aluguerAtual = lista_alugueres;
    while (aluguerAtual != NULL)
    {
        printf("| Codigo: %d | Custo: %f | Email: %s |\n", aluguerAtual->codigo, aluguerAtual->custo, aluguerAtual->email);
        aluguerAtual = aluguerAtual->next;
    }
    return 0;
}

/**
 * @brief Fun��o utilizada para imprimir todos os Gestores
 * @param Lista ligada que cont�m os dados dos gestores
 */
int imprimirGestores(Gestores* lista_gestores) {
    Gestores* gestorAtual = lista_gestores;
    while (gestorAtual != NULL)
    {
        printf("| ID: %d | Codigo: %d |\n", gestorAtual->id, gestorAtual->codigo);
        gestorAtual = gestorAtual->next;
    }
    return 0;
}

/**
 * @brief Fun��o utilizada para verificar a exist�ncia de um ID
 * @param[1] ID a comparar
 * @param[2] Lista ligada que cont�m os dados dos gestores
 * @return 1 se encontrar o ID ou 0 se o ID n�o existir
 */
int verificarGestor(int id, Gestores* lista_gestores) {
    int verificar = 0;

    Gestores* gestorAtual = lista_gestores;
    while (gestorAtual != NULL)
    {
        if (gestorAtual->id == id) {
            verificar = 1;
            return verificar;
        }
        gestorAtual = gestorAtual->next;
    }
    return verificar;
}

/**
 * @brief Fun��o utilizada para validar o login de um cliente
 * @param[1] Email inserido pelo utilizador
 * @param[2] Password inserida pelo utilizador
 * @param[3] Lista ligada que cont�m os dados dos clientes
 * @return 1 se os dados estiverem corretos ou 0 se n�o tiverem
 */
int verificarCliente(char email[50], char password[50], Clientes* lista) {
    int verificar = 0;

    Clientes* clienteAtual = lista;
    while (clienteAtual != NULL)
    {
        if (strcmp(clienteAtual->email, email) == 0 && strcmp(clienteAtual->password, password) == 0)
        {
            verificar = 1;
            return verificar;
        }
        clienteAtual = clienteAtual->next;
    }
    return verificar;
}

/**
 * @brief Fun��o utilizada para validar o login de um gestor
 * @param[1] ID inserido pelo utilizador
 * @param[2] Codigo inserido pelo utilizador
 * @param[3] Lista ligada que cont�m os dados dos gestores
 * @return 1 se os dados estiverem corretos ou 0 se n�o tiverem
 */
int verificarGestorLogin(int id, int codigo, Gestores* lista_gestores) {
    int verificar = 0;
    Gestores* gestorAtual = lista_gestores;
    while (gestorAtual != NULL)
    {
        if (gestorAtual->id == id && gestorAtual->codigo == codigo) {
            verificar = 1;
            return verificar;
        }
        gestorAtual = gestorAtual->next;
    }
    return verificar;
}

/**
 * @brief Fun��o utilizada para verificar a exist�ncia de um meio
 * @param[1] Codigo a comparar
 * @param[2] Lista ligada que cont�m os dados dos meios
 * @return 1 se encontrar o meio ou 0 se o meio n�o existir
 */
int verificarCodigo(int codigo, Meios* lista_meios) {
    int verificar = 0;
    Meios* meioAtual = lista_meios;
    while (meioAtual != NULL)
    {
        if (meioAtual->codigo == codigo) {
            verificar = 1;
            return verificar;
        }
        meioAtual = meioAtual->next;
    }
    return verificar;
}

/**
 * @brief Fun��o utilizada para verificar a exist�ncia de um NIF
 * @param[1] NIF a comparar
 * @param[2] Lista ligada que cont�m os dados dos clientes
 * @return 1 se o NIF j� exisitr ou 0 se o NIF n�o existir
 */
int verificarNIF(char nif[50], Clientes* lista_clientes) {
    int verificar = 0;
    Clientes* clienteAtual = lista_clientes;
    while (clienteAtual != NULL)
    {
        if (strcmp(clienteAtual->nif, nif) == 0)
        {
            verificar = 1;
            return verificar;
        }
        clienteAtual = clienteAtual->next;
    }

    return verificar;
}

/**
 * @brief Fun��o utilizada para verificar a exist�ncia de um email
 * @param[1] Email a comparar
 * @param[2] Lista ligada que cont�m os dados dos clientes
 * @return 1 se o email j� exisitr ou 0 se o email n�o existir
 */
int verificarEmail(char email[50], Clientes* lista_clientes) {
    int verificar = 0;
    Clientes* clienteAtual = lista_clientes;
    while (clienteAtual != NULL)
    {
        if (strcmp(clienteAtual->email, email) == 0) {
            verificar = 1;
            break;
        }
        clienteAtual = clienteAtual->next;
    }
    return verificar;
}

/**
 * @brief Fun��o utilizada para verificar se o saldo do Cliente � suficiente para um determinado aluguer
 * @param[1] Lista ligada que cont�m os dados dos meios
 * @param[2] Lista ligada que cont�m os dados dos clientes
 * @param[3] Lista ligada que cont�m os dados dos alugueres
 * @param[4] Email do cliente
 * @param[5] C�digo do meio
 * @return Custo do aluguer ou 0 se o saldo n�o for suficiente
 */
int verificarSaldo(Meios* lista_meios, Clientes* lista_clientes, Alugueres* lista_alugueres,char email[50], int codigo) {
    Meios* meioAtual = lista_meios;

    while (meioAtual != NULL)
    {
        if (meioAtual->codigo == codigo)
        {
            Clientes* clienteAtual = lista_clientes;
            while (clienteAtual != NULL)
            {
                if (strcmp(clienteAtual->email, email) == 0) {
                    if (clienteAtual->saldo >= meioAtual->custo)
                    {
                        clienteAtual->saldo = clienteAtual->saldo - meioAtual->custo;
                        return meioAtual->custo;
                    }
                    else 
                    {
                        return 0;
                    }
                }
                clienteAtual = clienteAtual->next;
            }
            break;
        }
        meioAtual = meioAtual->next;
    }  
}

/**
 * @brief Fun��o utilizada para criar um gestor
 * @param[1] Lista ligada que cont�m os dados dos gestores
 * @param[2] ID do novo Gestor
 * @param[3] C�digo do novo Gestor
 * @return Lista com o novo Gestor
 */
Gestores* adicionarGestor(Gestores* lista_gestores, int id, int codigo) {
    Gestores* novoGestor = (Gestores*)malloc(sizeof(Gestores));
    if (novoGestor == NULL)
    {
        printf("Erro ao adicionar o Gestor!");
        return lista_gestores;
    }
    novoGestor->id = id;
    novoGestor->codigo = codigo;
    novoGestor->next = lista_gestores;

    return novoGestor;
}

/**
 * @brief Fun��o utilizada para criar um aluguer
 * @param[1] Lista ligada que cont�m os dados dos alugueres
 * @param[2] C�digo do meio
 * @param[3] Custo do Aluguer
 * @param[4] Email do cliente que realizou o aluguer
 * @return Lista com o novo aluguer
 */
Alugueres* realizarAluguer(Alugueres* lista_alugueres, int codigo, float custo, char email[50]) {
    Alugueres* novoAluguer = (Alugueres*)malloc(sizeof(Alugueres));
    if (novoAluguer == NULL)
    {
        printf("Erro ao realizar o Aluguer!");
        return lista_alugueres;
    }
    novoAluguer->codigo = codigo;
    novoAluguer->custo = custo;
    strcpy(novoAluguer->email, email);
    novoAluguer->next = lista_alugueres;

    return novoAluguer;
}

/**
 * @brief Fun��o utilizada para carregar o saldo de um cliente
 * @param[1] Email do cliente
 * @param[2] Montante do carregamento
 * @param[3] Lista ligada que cont�m os dados dos clientes
 */
Clientes* carregarSaldo(char email [50], float montante, Clientes* lista_clientes) {
    Clientes* clienteAtual = lista_clientes;
    while (clienteAtual != NULL)
    {
        if (strcmp(clienteAtual->email, email) == 0) {
            clienteAtual->saldo = clienteAtual->saldo + montante;
            break;
        }
        clienteAtual = clienteAtual->next;
    }
}

/**
 * @brief Fun��o utilizada para criar um cliente
 * @param[1] Nome do novo cliente
 * @param[2] Nif do novo cliente
 * @param[4] Email do novo cliente
 * @param[5] Password do novo cliente
 * @param[6] Saldo do novo cliente
 * @param[7] Lista ligada que cont�m os dados dos clientes
 * @return Lista com o novo Cliente
 */
Clientes* registarCliente(char nome[50], char nif[50], char email[50], char password[50], float saldo, Clientes* lista_clientes) {
    
    Clientes* novocliente = (Clientes*)malloc(sizeof(Clientes));
    
    if (novocliente == NULL)
    {
        printf("Erro ao registar utilizador!");
        return lista_clientes;
    }
    
    strcpy(novocliente->nome, nome);
    strcpy(novocliente->nif, nif);
    strcpy(novocliente->email, email);
    strcpy(novocliente->password, password);
    novocliente->saldo = saldo;
    novocliente->next = lista_clientes;

    return novocliente;

}

/**
 * @brief Fun��o utilizada para criar um novo Meio
 * @param[1] Codigo do meio
 * @param[2] Tipo/Nome do meio
 * @param[3] Custo do meio
 * @param[4] Lista ligada que cont�m os dados dos meios
 * @return Lista com o novo meio
 */
Meios* registarMeio(int codigo, char tipo[50], float custo, Meios* lista_meios) {
    Meios* novomeio = (Meios*)malloc(sizeof(Meios));
    if (novomeio == NULL)
    {
        printf("Erro ao registar meio!");
        return lista_meios;
    }
    novomeio->codigo = codigo;
    strcpy(novomeio->tipo, tipo);
    novomeio->custo = custo;
    novomeio->next = lista_meios;

    return novomeio;
}

/**
 * @brief Fun��o utilizada para remover um meio
 * @param[1] C�digo do meio a remover
 * @param[2] Lista ligada que cont�m os dados dos meios
 * @return Lista atualizada
 */
Meios* removerMeio(int codigo, Meios* lista_meios) {
    Meios* removermeio = lista_meios;

    Meios* anterior = NULL;

    while (removermeio != NULL)
    {
        if(removermeio->codigo == codigo){
            if (anterior == NULL)
            {
                lista_meios = removermeio->next;
            }
            else {
                anterior->next = removermeio->next;
            }
            free(removermeio);
            return lista_meios;
        }
        anterior = removermeio;
        removermeio = removermeio->next;
    }
    return lista_meios;
}

/**
 * @brief Fun��o utilizada para remover um cliente
 * @param[1] Email do cliente a remover
 * @param[2] Lista ligada que cont�m os dados dos clientes
 * @return Lista atualizada
 */
Clientes* removerCliente(char email[50], Clientes* lista_clientes) {

    Clientes* removercliente = lista_clientes;

    Clientes* anterior = NULL;

    while (removercliente != NULL)
    {
        if (strcmp(removercliente->email, email) == 0) {
            // Verifica se o n� a ser removido � o primeiro da lista
            if (anterior == NULL) {
                lista_clientes = removercliente->next;
            }
            else {
                anterior->next = removercliente->next;
            }
            free(removercliente);
            return lista_clientes;
        }
        anterior = removercliente;
        removercliente = removercliente->next;
    }
    return lista_clientes;
}

/**
 * @brief Fun��o utilizada para remover um gestor
 * @param[1] ID do gestor a remover
 * @param[2] Lista ligada que cont�m os dados dos gestores
 * @return Lista atualizada
 */
Gestores* removerGestor(int id, Gestores* lista_gestores) {
    Gestores* removergestor = lista_gestores;

    Gestores* anterior = NULL;

    while (removergestor != NULL)
    {
        if (removergestor->id == id) {
            if (anterior == NULL)
            {
                lista_gestores = removergestor->next;
            }
            else {
                anterior->next = removergestor->next;
            }
            free(removergestor);
            return lista_gestores;
        }
        anterior = removergestor;
        removergestor = removergestor->next;
    }
    return lista_gestores;
}

/**
 * @brief Fun��o utilizada para alterar o email do cliente
 * @param[1] Email do cliente
 * @param[2] Novo email do cliente
 * @param[3] Lista ligada que cont�m os dados dos clientes
 */
Clientes* alterarEmailCliente(char email[50], char novoemail[50], Clientes* lista_clientes) {
    Clientes* clienteAtual = lista_clientes;
    while (clienteAtual != NULL)
    {
        if (strcmp(clienteAtual->email, email) == 0) {
            strcpy(clienteAtual->email, novoemail);
            break;
        }
        clienteAtual = clienteAtual->next;
    }

}

/**
 * @brief Fun��o utilizada para alterar o email do cliente nos alugueres
 * @param[1] Email do cliente
 * @param[2] Novo email do cliente
 * @param[3] Lista ligada que cont�m os dados dos alugueres
 */
Alugueres* alterarEmail(char email[50], char novoemail[50], Alugueres* lista_alugueres) {
    Alugueres* aluguerAtual = lista_alugueres;
    while (aluguerAtual != NULL)
    {
        if (strcmp(aluguerAtual->email, email) == 0) {
            strcpy(aluguerAtual->email, novoemail);
            break;
        }
        aluguerAtual = aluguerAtual->next;
    }
}

/**
 * @brief Fun��o de apoio para ordenar a lista dos clientes por ordem Alfab�tica
 */
void trocaClientes(Clientes* cliente1, Clientes* cliente2) {
    char tempNome[50];
    char tempNif[50];
    char tempEmail[50];
    char tempPassword[50];
    float tempSaldo;

    /* Troca os dados dos clientes */
    strcpy(tempNome, cliente1->nome);
    strcpy(cliente1->nome, cliente2->nome);
    strcpy(cliente2->nome, tempNome);

    strcpy(tempNif, cliente1->nif);
    strcpy(cliente1->nif, cliente2->nif);
    strcpy(cliente2->nif, tempNif);

    strcpy(tempEmail, cliente1->email);
    strcpy(cliente1->email, cliente2->email);
    strcpy(cliente2->email, tempEmail);

    strcpy(tempPassword, cliente1->password);
    strcpy(cliente1->password, cliente2->password);
    strcpy(cliente2->password, tempPassword);

    tempSaldo = cliente1->saldo;
    cliente1->saldo = cliente2->saldo;
    cliente2->saldo = tempSaldo;
}

/**
 * @brief Fun��o utilizada para ordenar a lista clientes (bubblesort)
 * @param Lista ligada que cont�m os dados dos clientes
 */
void bubbleSortClientes(Clientes* lista_clientes) {
    int swapped;
    Clientes* ptr1;
    Clientes* lptr = NULL;

    if (lista_clientes == NULL)
        return;

    do {
        swapped = 0;
        ptr1 = lista_clientes;

        while (ptr1->next != lptr) {
            if (strcmp(ptr1->nome, ptr1->next->nome) > 0) {
                trocaClientes(ptr1, ptr1->next);
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    } while (swapped);
}