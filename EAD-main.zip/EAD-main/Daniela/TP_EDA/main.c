/// Instituto Polit�cnico do C�vado e do Ave
/// Estruras de Dados Avan�adas
/// Autor: Daniela Loureiro Pereira
/// Tema: Aplica��o para gerir Aluguer de Mobilidade
/// 13 de Mar�o de 2023

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "fonte.h"


#pragma region Menus

/**
 * @brief Fun��o que representa o menu dos Clientes
 */
int menuCliente(Clientes* lista_clientes, char email[50], Alugueres* lista_alugueres, Meios* lista_meios) {
	
	int escolha;

	system("cls");
	printf(" _______________________________________\n");
	printf("|\t\tBEM VINDO\t\t|\n");
	printf("|\t\t\t\t\t|\n");
	printf("|\t\t1-Alterar Email\t\t|\n");
	printf("|\t\t2-Alugar Meio\t\t|\n");
	printf("|\t\t3-Carregar Saldo\t|\n");
	printf("|\t\t4-Desativar Conta\t|\n");
	printf("|\t\t5-Sair\t\t\t|\n");
	printf("|\033[4m\t\t\t\t\t\033[0m|\n");
	printf("|_______________________________________|\n");
	printf("| Escolha: ");
	scanf("%d", &escolha);

	char novoemail [50];
	int verificar, codigo;
	float montante;

	switch (escolha)
	{
	case 1:
		system("cls");
		printf("\t\t-->Novo Email: ");
		scanf(" %s", novoemail);
		verificar = verificarEmail(novoemail, lista_clientes);
		if (verificar == 1)
		{
			system("cls");
			printf("Email atualmente em uso! Pressione qualquer tecla para voltar ao menu...");
			getch();
			menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
		}
		alterarEmailCliente(email, novoemail, lista_clientes, lista_meios);
		alterarEmail(email, novoemail, lista_alugueres);
		strcpy(email, novoemail);
		printf("Email alterado com sucesso! Pressione qualquer tecla para voltar ao menu...");
		getch();
		menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
		break;
	case 2:
		system("cls");
		imprimirMeiosDisponiveis(lista_meios, lista_alugueres);
		printf("| Insira o codigo do meio: ");
		scanf("%d", &codigo);
		verificar = verificarSaldo(lista_meios, lista_clientes, lista_alugueres, email, codigo);
		if (verificar != 0)
		{
			lista_alugueres = realizarAluguer(lista_alugueres, codigo, verificar, email);
			printf("\nAluguer realizado com sucesso! Pressione qualquer tecla para voltar ao menu...");
			getch();
			menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
		}
		else
		{
			system("cls");
			printf("Saldo Insuficiente! Pressione qualquer tecla para voltar ao menu...");
			getch();
			menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
		}
		break;
	case 3:
		system("cls");
		printf("\t\t-->Montante: ");
		scanf("%f", &montante);
		carregarSaldo(email, montante, lista_clientes);
		menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
		break;
	case 4:
		system("cls");
		printf("Removendo a conta... Pressione qualquer tecla para continuar...");
		removerCliente(email, lista_clientes);
		getch();
		break;
	case 5:
		guardarDadosClientes(lista_clientes);
		guardarDadosMeios(lista_meios);
		guardarDadosAlugueres(lista_alugueres);
		exit;
	}
}

/**
 * @brief Menu de apoio
 */
int menuGestorEscolha() {
	int escolha;

	system("cls");
	printf(" _______________________________________\n");
	printf("|\t\t\t\t\t|\n");
	printf("|\t\t1-Gestor\t\t|\n");
	printf("|\t\t2-Cliente\t\t|\n");
	printf("|\t\t3-Meio\t\t\t|\n");
	printf("|\t\t4-Voltar\t\t|\n");
	printf("|\033[4m\t\t\t\t\t\033[0m|\n");
	printf("|_______________________________________|\n");
	printf("| Escolha: ");
	scanf("%d", &escolha);

	return escolha;
}

/**
 * @brief Fun��o que representa o menu dos Gestores
 */
void menuGestor(Gestores* lista_gestores, Clientes* lista_clientes, Meios* lista_meios, Alugueres* lista_alugueres) {
	int escolha, verificar;

	system("cls");
	printf(" _______________________________________\n");
	printf("|\t\tBEM VINDO\t\t|\n");
	printf("|\t\t\t\t\t|\n");
	printf("|\t\t1-Adicionar\t\t|\n");
	printf("|\t\t2-Alterar\t\t|\n");
	printf("|\t\t3-Remover\t\t|\n");
	printf("|\t\t4-Sair\t\t\t|\n");
	printf("|\033[4m\t\t\t\t\t\033[0m|\n");
	printf("|_______________________________________|\n");
	printf("| Escolha: ");
	scanf("%d", &escolha);

	int id, codigo, opcao;
	char nome[50], nif[50], email[50], password[50], tipo[50];
	float saldo, custo;

	switch (escolha)
	{
	case 1:
		opcao = menuGestorEscolha();
		switch (opcao)
		{
		case 1:
			system("cls");
			printf("\t\t-->ID: ");
			scanf("%d", &id);
			verificar = verificarGestor(id, lista_gestores);
			if (verificar == 1)
			{
				system("cls");
				printf("ID de Gestor em uso! Pressione qualquer tecla para voltar ao menu...");
				getch();
				menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
			}
			else
			{
				printf("\t\t-->Codigo: ");
				scanf("%d", &codigo);
				lista_gestores = adicionarGestor(lista_gestores, id, codigo);
				system("cls");
				printf("Gestor criado com sucesso! Pressione qualquer tecla para voltar ao menu...");
				getch();
				menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
			}
		case 2:
			system("cls");
			printf("\t\t-->Nome: ");
			scanf("%s", nome);
			printf("\t\t-->Nif: ");
			scanf("%s", nif);
			verificar = verificarNIF(nif, lista_clientes);
			if (verificar == 1) {
				system("cls");
				printf("Nif atualmente em uso! Pressione qualquer teclar para voltar ao menu...");
				getch();
				menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
			}
			printf("\t\t-->Email: ");
			scanf("%s", email);
			verificar = verificarEmail(email, lista_clientes);
			if (verificar == 1)
			{
				system("cls");
				printf("Email atualmente em uso! Pressione qualquer teclar para voltar ao menu...");
				getch();
				menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
			}
			printf("\t\t-->Password: ");
			scanf("%s", password);
			printf("\t\t-->Saldo: ");
			scanf("%f", &saldo);
			lista_clientes = registarCliente(nome, nif, email, password, saldo, lista_clientes);
			printf("\nCliente criado com sucesso! Pressione qualquer tecla para voltar ao menu...");
			getch();
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		case 3:
			system("cls");
			printf("\t\t-->Codigo: ");
			scanf("%d", &codigo);
			verificar = verificarCodigo(codigo, lista_meios);
			if (verificar == 1)
			{
				system("cls");
				printf("Codigo atualmente em uso! Pressione qualquer teclar para voltar ao menu...");
				getch();
				menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
			}
			printf("\t\t-->Tipo: ");
			scanf("%s", tipo);
			printf("\t\t-->Custo: ");
			scanf("%f", &custo);
			lista_meios = registarMeio(codigo, tipo, custo, lista_meios);
			system("cls");
			printf("Meio criado com sucesso! Pressione qualquer tecla para voltar ao menu...");
			getch();
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		case 4:
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		}
	case 2:
		printf("N�o implementado! Pressione qualquer tecla para voltar ao menu...");
		getch();
		menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
	case 3:
		opcao = menuGestorEscolha();
		switch (opcao)
		{
		case 1:
			system("cls");
			imprimirGestores(lista_gestores);
			printf("\n\nInsira o ID do gestor que deseja remover: ");
			scanf("%d", &id);
			removerGestor(id, lista_gestores);
			getch();
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		case 2:
			system("cls");
			imprimirClientes(lista_clientes);
			printf("\n\nInsira o email do cliente que deseja remover: ");
			scanf("%s", email);
			removerCliente(email, lista_clientes);
		case 3:
			system("cls");
			imprimirMeios(lista_meios);
			printf("\n\nInsira o codigo do meio que deseja remover: ");
			scanf("%d", &codigo);
			removerMeio(codigo, lista_meios);
			getch();
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		case 4:
			menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
		}
	case 4: 
		guardarDadosClientes(lista_clientes);
		guardarDadosMeios(lista_meios);
		guardarDadosAlugueres(lista_alugueres);
		guardarDadosGestores(lista_gestores);
		exit;
	}
}

/**
 * @brief Fun��o que representa o menu de login dos Gestores
 */
void menuLoginGestor(Gestores* lista_gestores, Clientes* lista_clientes, Meios* lista_meios, Alugueres* lista_alugueres) {

	int id, codigo, verificar;

	system("cls");
	printf(" _______________________________________\n");
	printf("|\t\tLOGIN\t\t\t|\n");
	printf("|_______________________________________|\n");
	printf("\t--> ID: ");
	scanf("%d", &id);
	printf("\t--> Codigo: ");
	scanf("%d", &codigo);
	verificar = verificarGestorLogin(id, codigo, lista_gestores);

	if (verificar == 1)
	{
		menuGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
	}
	else
	{
		system("cls");
		printf("Dados Incorretos! Pressione qualquer tecla...");
		getch();
		menuLoginGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
	}
}

/**
 * @brief Menu principal
 */
void menu(Clientes* lista_clientes, Gestores* lista_gestores, Meios* lista_meios, Alugueres* lista_alugueres) {
	int escolha;

	system("cls");
	printf(" _______________________________________\n");
	printf("|\t\tBEM-VINDO\t\t|\n");
	printf("|\t\t\t\t\t|\n");
	printf("|\t\t1-Gestor\t\t|\n");
	printf("|\t\t2-Cliente\t\t|\n");
	printf("|\033[4m\t\t\t\t\t\033[0m|\n");
	printf("|_______________________________________|\n");
	printf("| Escolha: ");
	scanf("%d", &escolha);

	/// <summary>
	/// Menus dos Gestores
	/// </summary>
	if (escolha == 1)
	{
		menuLoginGestor(lista_gestores, lista_clientes, lista_meios, lista_alugueres);
	}
	/// <summary>
	/// Menus dos Clientes
	/// </summary>
	else if (escolha == 2)
	{
		guardarDadosGestores(lista_gestores);
		system("cls");
		printf(" _______________________________________\n");
		printf("|\t\tBEM-VINDO\t\t|\n");
		printf("|\t\t\t\t\t|\n");
		printf("|\t\t1-Login\t\t\t|\n");
		printf("|\t\t2-Registar\t\t|\n");
		printf("|\033[4m\t\t\t\t\t\033[0m|\n");
		printf("|_______________________________________|\n");
		printf("| Escolha: ");
		scanf("%d", &escolha);

		if (escolha == 1)
		{
			char email[50], password[50];
			char novoemail[50];
			int verificar;
			system("cls");
			printf(" _______________________________________\n");
			printf("|\t\tLOGIN\t\t\t|\n");
			printf("|_______________________________________|\n");
			printf("\t--> Email: ");
			scanf("%s", email);
			printf("\t--> Password: ");
			scanf("%s", password);
			verificar = verificarCliente(email, password, lista_clientes);
			if (verificar == 1)
			{
				menuCliente(lista_clientes, email, lista_alugueres, lista_meios);
			}
			else
			{
				system("cls");
				printf("Dados Incorretos! Pressione qualquer tecla para continuar...");
				getch();
				menu(lista_clientes,lista_gestores, lista_meios, lista_alugueres);
			}
		}
		else if (escolha == 2)
		{
			int verificar;
			char nome[50], nif[50], email[50], password[50];
			system("cls");
			printf("\t\t--> Nome: ");
			scanf("%s", nome);
			printf("\t\t--> NIF: ");
			scanf("%s", nif);
			verificar = verificarNIF(nif, lista_clientes);
			if (verificar == 1)
			{
				system("cls");
				printf("NIF atualmente em uso! Pressione qualquer tecla para regressar ao menu...");
				getch();
				menu(lista_clientes, lista_gestores, lista_meios, lista_alugueres);
			}
			printf("\t\t--> Email: ");
			scanf("%s", email);
			verificar = verificarEmail(email, lista_clientes);
			if (verificar == 1)
			{
				system("cls");
				printf("Email atualmente em uso! Pressione qualquer tecla para regressar ao menu...");
				getch();
				menu(lista_clientes, lista_gestores, lista_meios, lista_alugueres);
			}
			printf("\t\t--> Password: ");
			scanf("%s", password);
			lista_clientes = registarCliente(nome, nif, email, password, 0, lista_clientes);
			system("cls");
			printf("Cliente registado com sucesso! Pression qualquer tecla para regressar ao menu...");
			getch();
			menu(lista_clientes, lista_gestores, lista_meios, lista_alugueres);
		}
	}	
}

/**
 * @brief Fun��o main
 */
void main()
{
	Clientes* lista_clientes = receberDadosClientes();
	Gestores* lista_gestores = receberDadosGestores();
	Meios* lista_meios = receberDadosMeios();
	Alugueres* lista_alugueres = receberDadosAlugueres();
	bubbleSortClientes(lista_clientes);
	menu(lista_clientes, lista_gestores, lista_meios, lista_alugueres);
}