var searchData=
[
  ['gestores_15',['gestores',['../structgestores.html',1,'']]],
  ['gestores_16',['Gestores',['../fonte_8h.html#a3b49d0c8bcb993e5876f43ca6e4edff6',1,'fonte.h']]],
  ['guardardadosalugueres_17',['guardarDadosAlugueres',['../fonte_8c.html#a9a43fec5ef5eab3f9f282b55ce37de9e',1,'guardarDadosAlugueres(Alugueres *lista_alugueres):&#160;fonte.c'],['../fonte_8h.html#a9a43fec5ef5eab3f9f282b55ce37de9e',1,'guardarDadosAlugueres(Alugueres *lista_alugueres):&#160;fonte.c']]],
  ['guardardadosclientes_18',['guardarDadosClientes',['../fonte_8c.html#abd933b20976352df99c6d47e32aecea4',1,'guardarDadosClientes(Clientes *lista_clientes):&#160;fonte.c'],['../fonte_8h.html#abd933b20976352df99c6d47e32aecea4',1,'guardarDadosClientes(Clientes *lista_clientes):&#160;fonte.c']]],
  ['guardardadosgestores_19',['guardarDadosGestores',['../fonte_8c.html#a7704bc560f411bc784887ab487f313d6',1,'guardarDadosGestores(Gestores *lista_gestores):&#160;fonte.c'],['../fonte_8h.html#a7704bc560f411bc784887ab487f313d6',1,'guardarDadosGestores(Gestores *lista_gestores):&#160;fonte.c']]],
  ['guardardadosmeios_20',['guardarDadosMeios',['../fonte_8c.html#a70f8607cf54141d7edb1dca4119b991b',1,'guardarDadosMeios(Meios *lista_meios):&#160;fonte.c'],['../fonte_8h.html#a70f8607cf54141d7edb1dca4119b991b',1,'guardarDadosMeios(Meios *lista_meios):&#160;fonte.c']]]
];
