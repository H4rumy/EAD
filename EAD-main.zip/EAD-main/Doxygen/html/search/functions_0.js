var searchData=
[
  ['adicionargestor_67',['adicionarGestor',['../fonte_8c.html#a661df891db9b6d55e9ebb8e5776f1ec6',1,'adicionarGestor(Gestores *lista_gestores, int id, int codigo):&#160;fonte.c'],['../fonte_8h.html#a661df891db9b6d55e9ebb8e5776f1ec6',1,'adicionarGestor(Gestores *lista_gestores, int id, int codigo):&#160;fonte.c']]],
  ['alteraremail_68',['alterarEmail',['../fonte_8c.html#a7a5873d65936037b61d6b414355b978a',1,'alterarEmail(char email[50], char novoemail[50], Alugueres *lista_alugueres):&#160;fonte.c'],['../fonte_8h.html#a7a5873d65936037b61d6b414355b978a',1,'alterarEmail(char email[50], char novoemail[50], Alugueres *lista_alugueres):&#160;fonte.c']]],
  ['alteraremailcliente_69',['alterarEmailCliente',['../fonte_8c.html#a410ea4b4d139f6541b170b9855c1a815',1,'alterarEmailCliente(char email[50], char novoemail[50], Clientes *lista_clientes):&#160;fonte.c'],['../fonte_8h.html#a410ea4b4d139f6541b170b9855c1a815',1,'alterarEmailCliente(char email[50], char novoemail[50], Clientes *lista_clientes):&#160;fonte.c']]]
];
