var searchData=
[
  ['gestores_62',['gestores',['../structgestores.html',1,'']]]
];
