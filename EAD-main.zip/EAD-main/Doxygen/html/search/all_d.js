var searchData=
[
  ['tipo_51',['tipo',['../structmeios.html#aaaedbaf92035e55fc401cfe8e6bbffb2',1,'meios']]],
  ['trocaclientes_52',['trocaClientes',['../fonte_8c.html#ab31100ee562440fd977150eff167f319',1,'trocaClientes(Clientes *cliente1, Clientes *cliente2):&#160;fonte.c'],['../fonte_8h.html#ab31100ee562440fd977150eff167f319',1,'trocaClientes(Clientes *cliente1, Clientes *cliente2):&#160;fonte.c']]]
];
