var searchData=
[
  ['tipo_114',['tipo',['../structmeios.html#aaaedbaf92035e55fc401cfe8e6bbffb2',1,'meios']]]
];
