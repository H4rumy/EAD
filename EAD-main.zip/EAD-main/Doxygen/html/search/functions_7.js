var searchData=
[
  ['trocaclientes_97',['trocaClientes',['../fonte_8c.html#ab31100ee562440fd977150eff167f319',1,'trocaClientes(Clientes *cliente1, Clientes *cliente2):&#160;fonte.c'],['../fonte_8h.html#ab31100ee562440fd977150eff167f319',1,'trocaClientes(Clientes *cliente1, Clientes *cliente2):&#160;fonte.c']]]
];
