var searchData=
[
  ['next_109',['next',['../structmeios.html#a47baf0823e1b2ccb76509ee764e75e9a',1,'meios::next()'],['../structclientes.html#a6f08ff745000bb590230aed6da967059',1,'clientes::next()'],['../structgestores.html#a3253526de9c74e871294cc8c7151d47d',1,'gestores::next()'],['../structalugueres.html#a60197ac191dacb6876c0c643d988f224',1,'alugueres::next()']]],
  ['nif_110',['nif',['../structclientes.html#a5abf1684317a9b2b7ed91ef415aad7f4',1,'clientes']]],
  ['nome_111',['nome',['../structclientes.html#af38e3eec33f0432d66a923ef567a84d1',1,'clientes']]]
];
