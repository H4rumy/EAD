var indexSectionsWithContent =
{
  0: "_abcefgimnprstv",
  1: "acgm",
  2: "fm",
  3: "abcgimrtv",
  4: "ceinpst",
  5: "acgm",
  6: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de tipos",
  6: "Macros"
};

