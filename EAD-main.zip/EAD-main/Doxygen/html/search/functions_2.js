var searchData=
[
  ['carregarsaldo_71',['carregarSaldo',['../fonte_8c.html#a212b4c873a78109d0012ec63b0fcc0df',1,'carregarSaldo(char email[50], float montante, Clientes *lista_clientes):&#160;fonte.c'],['../fonte_8h.html#a212b4c873a78109d0012ec63b0fcc0df',1,'carregarSaldo(char email[50], float montante, Clientes *lista_clientes):&#160;fonte.c']]]
];
